//instância é quando um objeto representa a classe 
//POO - Programação Orientada a Objeto 
/*Model View e-Controler - MVC - ORGANIZAÇÃO ENTRE MEUS DADOS, 
INTERFACE E O QUE ESTÁ ACONTECENDO (REGRA DE NOGÓCIO)
Model trata sobre os dados (bdd)
*/

window.calculator = new CalcController; 